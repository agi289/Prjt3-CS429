#include "tdmm.h"

void
t_init (alloc_strat_e strat)
{
  // TODO: Implement this
}

void *
t_malloc (size_t size)
{
  // TODO: Implement this
  return NULL;
}

void
t_free (void *ptr)
{
  // TODO: Implement this
}

void
t_gcollect (void)
{
  // TODO: Implement this
}