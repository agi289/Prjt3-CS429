#include "tdmm.h"

int
main ()
{
  return 0;
}